fx_version 'cerulean'
game 'gta5'

author 'Project Alpha - moritzoida'
description 'FiveM Jobcenter für ESX'
version '1.0.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'
