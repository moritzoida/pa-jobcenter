ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(100)
    end
end)

local inZone = false

function ShowHelpNotification(msg)
    BeginTextCommandDisplayHelp("STRING")
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandDisplayHelp(0, false, true, -1)
end

Citizen.CreateThread(function()
    while true do
        local sleep = 1000
        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        local dist = #(coords - Config.JobCenter.coords)

        if dist < Config.JobCenter.drawDistance then
            sleep = 0
            DrawMarker(
                Config.JobCenter.markerType,
                Config.JobCenter.coords.x, Config.JobCenter.coords.y, Config.JobCenter.coords.z - 1,
                0.0, 0.0, 0.0,
                0, 0, 0,
                Config.JobCenter.markerSize.x, Config.JobCenter.markerSize.y, Config.JobCenter.markerSize.z,
                Config.JobCenter.markerColor.r, Config.JobCenter.markerColor.g, Config.JobCenter.markerColor.b, Config.JobCenter.markerColor.a,
                false, true, 2, nil, nil, false
            )

            if dist < 1.5 and not inZone then
                inZone = true
                ShowHelpNotification("Drücke ~INPUT_CONTEXT~, um einen Job auszuwählen.")
            elseif dist >= 1.5 and inZone then
                inZone = false
            end

            if inZone and IsControlJustReleased(0, 38) then -- E-Taste
                OpenJobMenu()
            end
        end

        Citizen.Wait(sleep)
    end
end)

function OpenJobMenu()
    local elements = {}

    for _, job in ipairs(Config.Jobs) do
        table.insert(elements, {
            label = job.label,
            value = job.job
        })
    end

    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'jobcenter_menu', {
        title = "Jobcenter",
        align = 'top-left',
        elements = elements
    }, function(data, menu)
        local job = data.current.value
        TriggerServerEvent('jobcenter:setJob', job)
        ESX.ShowNotification("Du hast den Job ~b~" .. data.current.label .. "~s~ angenommen.")
        menu.close()
    end, function(data, menu)
        menu.close()
    end)
end

Citizen.CreateThread(function()
    local blip = AddBlipForCoord(Config.JobCenter.coords)

    SetBlipSprite(blip, 408) -- Symbol: Briefumschlag (Jobcenter)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 0.7)
    SetBlipColour(blip, 3) -- Gr�n
    SetBlipAsShortRange(blip, true)

    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Jobcenter")
    EndTextCommandSetBlipName(blip)
end)
