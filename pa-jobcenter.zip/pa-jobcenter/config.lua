Config = {}

-- Koordinaten des Jobcenters
Config.JobCenter = {
    coords = vector3(-268.63, -957.24, 31.22),
    markerType = 1,
    markerSize = vector3(1.5, 1.5, 1.0),
    markerColor = { r = 0, g = 153, b = 255, a = 150 },
    drawDistance = 20.0
}

-- Job Liste
Config.Jobs = {
    { label = "Trucker", job = "trucker" },
}
