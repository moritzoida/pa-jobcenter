ESX = exports["es_extended"]:getSharedObject()

RegisterServerEvent('jobcenter:setJob')
AddEventHandler('jobcenter:setJob', function(job)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        xPlayer.setJob(job, 0)
    end
end)
